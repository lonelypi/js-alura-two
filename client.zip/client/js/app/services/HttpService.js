class HttpService {

    get(url) {
        return new Promise((resolve, reject) => {
                let xhr = new XMLHttpRequest();

                xhr.open('GET', url);

                /* configurações */

                xhr.onreadystatechange = () => {

                    if (xhr.readyState == 4) {//Requisição concluísa e a resposta está pronta

                        if (xhr.status == 200) {//Se for 200 quer dizer que ocorreu tudo certo.

                            resolve(JSON.parse(xhr.responseText));
                            
                        } else {

                            reject(xhr.responseText);

                        }
                    }

                };

                /* fim configurações */

                xhr.send();
            });
    }
}