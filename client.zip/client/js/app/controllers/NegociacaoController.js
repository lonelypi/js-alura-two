class NegociacaoController {
    //AULA 3

    //Metodo, função que pertence a um objeto. Função está sozinha.
    //Preciso usar o metodo bind, para manter a associação (com document)
    //  fazendo uma referência ao `document` no caso usado.

    constructor() {

        let $ = document.querySelector.bind(document);

        this._inputData = $('#data');
        this._inputQuantidade = $('#quantidade');
        this._inputValor = $('#valor');

        // this._listaNegociacoes = new ListaNegociacoes(model => this._negociacoesView.update(model));

        //O escopo do this de uma arrow function é lexico, ou seja, não é dinâmico. Ele mantém aqui /\
        // como sendo de NegociacaoController. ARROW FUNCTION É MUITO MAIS QUE UMA NOVA FORMA DE CHAMAR FUNÇÃO.

        this._listaNegociacoes = new Bind(new ListaNegociacoes(), new NegociacoesView($('#negociacoesView')),
            'adiciona', 'esvazia');

        this._mensagem = new Bind(new Mensagem(), new MensagemView($('#mensagemView')),
            'texto');

    }
    //A reticencias se chama spread operator! Que separa cada valor do array.
    //Metodo map é usado para formar algo novo, ele possui um return.

    adiciona(event) {
        event.preventDefault();

        //AULA 4
        // console.log(DateHelper.dataParaTexto(negociacao.data));

        this._listaNegociacoes.adiciona(this._criaNegociacao());
        this._mensagem.texto = 'Negociação adicionado com sucesso';
        this._limpaFormulario();
    }

    importaNegociacoes() {

        let service = new NegociacaoService();

        Promise
        .all([
            service.obterNegociacaoDaSemana(),
            service.obterNegociacaoDaSemanaAnterior(),
            service.obterNegociacaoDaSemanaRetrasada()
        ])
        .then(negociacoes => {
            negociacoes
                .reduce((arrayAchatado, array) => arrayAchatado.concat(array), [])
                .forEach(negociacao => this._listaNegociacoes.adiciona(negociacao));
            this._mensagem.texto="Negociações importadas com sucesso!";
        })
        .catch(err => this._mensagem.texto = err);

        /*
        service.obterNegociacaoDaSemana()
            .then(negociacoes => {
                negociacoes.forEach(negociacao => this._listaNegociacoes.adiciona(negociacao));
                this._mensagem.texto = 'Negociações da semana obtidas com sucesso!';
            })
            .catch(err => this._mensagem.texto = err);


        service.obterNegociacaoDaSemanaAnterior()
            .then(negociacoes => {
                negociacoes.forEach(negociacao => this._listaNegociacoes.adiciona(negociacao));
                this._mensagem.texto = 'Negociações da semana obtidas com sucesso!';
            })
            .catch(err => this._mensagem.texto = err);


        service.obterNegociacaoDaSemanaRetrasada()
            .then(negociacoes => {
                negociacoes.forEach(negociacao => this._listaNegociacoes.adiciona(negociacao));
                this._mensagem.texto = 'Negociações da semana obtidas com sucesso!';
            })
            .catch(err => this._mensagem.texto = err);

        
        service.obterNegociacaoDaSemana((err, negociacoes) => {
            //!!Error first!!
            if (err) {
                this._mensagem.texto = err;
                return;
            }

            negociacoes.forEach(negociacao => this._listaNegociacoes.adiciona(negociacao));
            service.obterNegociacaoDaSemanaAnterior((err, negociacoes) => {
                //!!Error first!!
                if (err) {
                    this._mensagem.texto = err;
                    return;
                }
    
                negociacoes.forEach(negociacao => this._listaNegociacoes.adiciona(negociacao));
    
                service.obterNegociacaoDaSemanaRetrasada((err, negociacoes) => {
                    //!!Error first!!
                    if (err) {
                        this._mensagem.texto = err;
                        return;
                    }
        
                    negociacoes.forEach(negociacao => this._listaNegociacoes.adiciona(negociacao));
                    this._mensagem.text = 'Negociações importadas com sucesso';
        
                });
            });
        });
        */

    }

    apaga() {
        this._listaNegociacoes.esvazia();
        this._mensagem.texto = "Negociações apagadas com sucesso!";
    }

    // "_" pq o método só pode ser chamado pela própria classe.
    _criaNegociacao() {

        return new Negociacao(
            DateHelper.textoParaData(this._inputData.value),
            this._inputQuantidade.value,
            this._inputValor.value
        )

    }


    _limpaFormulario() {
        this._inputData.value = '';
        this._inputQuantidade.value = 1;
        this._inputValor.value = 0.0

        this._inputData.focus();
    }

}


//O Proxy fica entre o objeto real, o proxy pode executar um código antes de chamar o objeto real